from flask import Flask, render_template, request, jsonify
import google.generativeai as genai

app = Flask(__name__)

# Your Gemini API key
GEMINI_API_KEY = 'AIzaSyCclRMJ0cdftV0xAhHS7yPEyMWbc3TZtPs'

products_schema = [
    {
        "Product_name": "Eco-friendly Water Bottle",
        "Product_description": "A reusable water bottle made from stainless steel, featuring double-wall insulation to keep beverages hot or cold for hours.",
        "Reason": "Chosen for its environmental benefits and the growing consumer preference for sustainable products."
    },
    {
        "Product_name": "Noise-Canceling Headphones",
        "Product_description": "Wireless headphones with active noise cancellation, high-fidelity sound, and long battery life.",
        "Reason": "Selected due to the increasing demand for high-quality audio devices in both professional and casual settings."
    },
    {
        "Product_name": "Smart Home Hub",
        "Product_description": "A central device that connects and controls various smart home appliances, featuring voice control and a user-friendly app interface.",
        "Reason": "Picked for its convenience and the expanding market for smart home technology."
    },
    {
        "Product_name": "Electric Scooter",
        "Product_description": "A compact and foldable electric scooter with a powerful motor and long-lasting battery, ideal for urban commuting.",
        "Reason": "Chosen for its eco-friendly transportation benefits and increasing popularity in crowded cities."
    },
    {
        "Product_name": "Wireless Charger",
        "Product_description": "A sleek and fast wireless charging pad compatible with multiple devices, ensuring convenience and reducing cable clutter.",
        "Reason": "Selected for its practicality and the growing adoption of wireless charging technology."
    },
    {
        "Product_name": "Smart Thermostat",
        "Product_description": "An intelligent thermostat that learns your schedule and preferences, helping you save energy and stay comfortable.",
        "Reason": "Picked for its energy-saving potential and the trend towards smart home energy management."
    },
    {
        "Product_name": "Portable Solar Charger",
        "Product_description": "A lightweight and efficient solar charger for mobile devices, perfect for outdoor activities and emergencies.",
        "Reason": "Chosen for its renewable energy use and utility in off-grid situations."
    },
    {
        "Product_name": "Fitness Tracker",
        "Product_description": "A stylish and waterproof fitness tracker that monitors your activity, sleep, and heart rate, with a companion app.",
        "Reason": "Selected for its health benefits and the rising interest in personal fitness monitoring."
    },
    {
        "Product_name": "4K Action Camera",
        "Product_description": "A rugged and waterproof action camera capable of shooting 4K video and high-resolution photos, ideal for adventure enthusiasts.",
        "Reason": "Picked for its durability and the increasing demand for high-quality adventure recording equipment."
    },
    {
        "Product_name": "Smart Light Bulb",
        "Product_description": "An energy-efficient LED light bulb that can be controlled via a smartphone app or voice commands, offering various colors and brightness levels.",
        "Reason": "Chosen for its energy efficiency and the growing market for smart lighting solutions."
    },
    {
        "Product_name": "Robot Vacuum Cleaner",
        "Product_description": "A smart robot vacuum cleaner with powerful suction, multiple cleaning modes, and app control for effortless home cleaning.",
        "Reason": "Selected for its convenience and the increasing adoption of automated home cleaning devices."
    },
    {
        "Product_name": "Bluetooth Speaker",
        "Product_description": "A portable Bluetooth speaker with high-quality sound, long battery life, and water-resistant design, perfect for both indoor and outdoor use.",
        "Reason": "Picked for its versatility and the rising popularity of portable audio solutions."
    }
]






# Initialize the Gemini API client
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel('gemini-1.0-pro')
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate_gift_idea', methods=['POST'])
def generate_gift_idea():
    data = request.json
    age = data.get('age')
    gender = data.get('gender')
    occasion = data.get('occasion')
    recipient_type = data.get('recipient_type')
    categories = data.get('categories')
    prompt = f"You have a very good choice , so just Provide me a list of 12 highly-rated and trending different gift ideas for a {age}-year-old {recipient_type} who is {gender} and loves {categories} items. These gifts should be suitable for {occasion} and available on Amazon India. Ensure that each product followed by only its product_names, description of each product , each product followed by its description and a convincing reason for its selection and ensure that product are listed without any special characters such as *, here{products_schema} is an exaample with three products with its Product_name:, Description:, Reason_for_selection :, similarly do that for all 12 product "
    # Generate gift ideas using the Gemini API
    try:
      response = model.generate_content(prompt)
      generated_text = response.text
      gift_ideas = process_text_for_gift_ideas(generated_text)[:12]  # Get only 12 ideas
      return jsonify({"gift_ideas": gift_ideas})  # Get only 5 ideas
    except Exception as e:
      print(f"Error generating gift ideas: {e}")
      return jsonify({"error": "Error generating gift ideas"}), 500
@app.route('/search_gift_idea', methods=['POST'])
def search_gift_idea():
    data = request.json
    textdata= data.get('prompt')
    prompt=f"Task: Gift idea generation\n Description: Based on {textdata} generate gift idea suggestions that are available on Amazon India ecommerce website. Ensure that only the product names, descriptions and reason is provide as example in schema {products_schema}. Additionally, include each product followed by its description and a convincing reason for its selection provide me the output in the format: \nProduct:  \nDescription: \nReason:"

    # Generate gift ideas using the Gemini API based on the search prompt
    try:
        response = model.generate_content(prompt)
        generated_text = response.text
        gift_ideas = process_text_for_gift_ideas(generated_text)[:12]  # Get only 12 ideas
        return jsonify({"gift_ideas": gift_ideas})
    except Exception as e:
        print(f"Error generating gift ideas: {e}")
        return jsonify({"error": "Error generating gift ideas"}), 500



def process_text_for_gift_ideas(text):
    
    return text.split('\n')[:12]  

if __name__ == '__main__':
    app.run(debug=True)
